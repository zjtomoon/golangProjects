// +build windows

package bind

func systemdInit()       {}
func usingSystemd() bool { return false }
