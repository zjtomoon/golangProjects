import Vue from "vue";
import Vuex from "vuex";
Vue.use(Vuex);

const Store = {
	state: {
	},
	mutations: {
	},
	actions: {
	},
	getters: {
		
	}
};

const store = new Vuex.Store(Store);
export default store;
