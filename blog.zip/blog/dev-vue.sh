#!/bin/bash

# https://cn.vuejs.org/index.html
cd vue/ && npm run serve